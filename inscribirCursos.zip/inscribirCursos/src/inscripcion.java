import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class inscripcion extends javax.swing.JFrame {
    DefaultTableModel cursos=new DefaultTableModel();
    ArrayList<Object[]>datos=new ArrayList<>(); 
    private TableRowSorter filtro; 
    public void cargar(){
        ArrayList<Object>columna=new ArrayList<>(); 
        columna.add("ID");
        columna.add("Materia");
        columna.add("Semestre");
        columna.add("Grupo");
        columna.add("Profesor");
        columna.add("Turno");
        columna.add("Hora");
        columna.add("Salon");
        columna.add("Plantel");
        for(Object co:columna)
            cursos.addColumn(co);
        this.tabla.setModel(cursos);
        Object[] curso1=new Object[]{"1","so","6","301","A","Mat","7-8:30","AV","SLT"};
        Object[] curso2=new Object[]{"2","ps","6","302","B","Mat","8:30-10","AV","SLT"};
        Object[] curso3=new Object[]{"3","acs","6","303","C","Mat","10-11:30","AV","SLT"};
        Object[] curso4=new Object[]{"4","pw","6","304","D","Mat","11:30-13","AV","SLT"};
        Object[] curso5=new Object[]{"5","ams","6","305","E","Mat","13-14:30","AV","SLT"};
        datos.add(curso1);
        datos.add(curso2);
        datos.add(curso3);
        datos.add(curso4);
        datos.add(curso5);
        for(Object []info:datos)
            cursos.addRow(info);
        tabla.setModel(cursos);
    }
    
    public inscripcion() {
        initComponents();
        Color co1=new Color(127, 255, 212);
        Color co2=new Color(218, 112, 214);
        this.getContentPane().setBackground(co1);
        this.jButton1.setBackground(co2);
        this.jButton2.setBackground(co2);
        cargar();
    }
    
    public void filtro(){
        int col=1; 
        filtro.setRowFilter(RowFilter.regexFilter(tfBusqueda.getText(),col));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombre = new javax.swing.JLabel();
        lblMatricula = new javax.swing.JLabel();
        lblNom = new javax.swing.JLabel();
        lblMat = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        tfBusqueda = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Inscribir cursos");
        setBackground(new java.awt.Color(204, 0, 153));
        setForeground(java.awt.Color.magenta);

        lblNombre.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        lblNombre.setText("Nombre:");
        lblNombre.setName("lblNombre"); // NOI18N

        lblMatricula.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        lblMatricula.setText("Matricula:");
        lblMatricula.setName("lblMatricula"); // NOI18N

        lblNom.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblNom.setText("Alguien");
        lblNom.setName("lblAlumno"); // NOI18N

        lblMat.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblMat.setText("0000-000-0000");
        lblMat.setName("lblMat"); // NOI18N

        jLabel5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel5.setText("Ingrese nombre de la materia a buscar:");

        tfBusqueda.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        tfBusqueda.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        tfBusqueda.setName("tfBusqueda"); // NOI18N
        tfBusqueda.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                tfBusquedaCaretUpdate(evt);
            }
        });
        tfBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfBusquedaKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfBusquedaKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfBusquedaKeyTyped(evt);
            }
        });

        tabla = new javax.swing.JTable(){
            public boolean  isCellEditable(int row,int column){
                return false;
            }
        }
        tabla.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabla.setFocusable(false);
        tabla.getTableHeader().setReorderingAllowed(false);
        tabla.setVerifyInputWhenFocusTarget(false);
        jScrollPane1.setViewportView(tabla);

        jButton1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(116, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblMatricula)
                                .addGap(18, 18, 18)
                                .addComponent(lblMat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblNombre)
                                .addGap(31, 31, 31)
                                .addComponent(lblNom, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(128, 128, 128))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(jButton1)
                        .addGap(65, 65, 65)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 514, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombre)
                    .addComponent(lblNom, javax.swing.GroupLayout.DEFAULT_SIZE, 19, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMatricula)
                    .addComponent(lblMat))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfBusquedaCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_tfBusquedaCaretUpdate
    }//GEN-LAST:event_tfBusquedaCaretUpdate

    private void tfBusquedaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfBusquedaKeyPressed
    }//GEN-LAST:event_tfBusquedaKeyPressed

    private void tfBusquedaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfBusquedaKeyTyped
        /*KeyTyped se invoca cuando se presiona una tecla que es caracter   
        KeyListener reescribre todos los metodos con una accion especifica para detectar el evento
        KeyReleased se invoca cuando se deja de pulsar la tecla*/
        tfBusqueda.addKeyListener(new KeyAdapter(){
            public void keyReleased(final KeyEvent e){
                String b=(tfBusqueda.getText()); 
                tfBusqueda.setText(b);
                filtro(); 
            }
        });
        filtro=new TableRowSorter(tabla.getModel());
        tabla.setRowSorter(filtro);
    }//GEN-LAST:event_tfBusquedaKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int filaSel=tabla.getSelectedRowCount(); 
        if(filaSel>0){
            int v=JOptionPane.showConfirmDialog(this,"¿Estas seguro que quieres inscribir los cursos seleccionados?","Advertencia",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
            if(v==JOptionPane.YES_OPTION)
                JOptionPane.showMessageDialog(this,"Se han agregado los cursos.");
            else
                JOptionPane.showMessageDialog(this,"No se han agregado los cursos.");
        }
        else
            JOptionPane.showMessageDialog(this,"No se pueden agregar cursos porque no ha seleccionado ninguno");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JOptionPane.showMessageDialog(this,"No se han agregado cursos.");
        System.exit(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tfBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfBusquedaKeyReleased
    }//GEN-LAST:event_tfBusquedaKeyReleased
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new inscripcion().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblMat;
    private javax.swing.JLabel lblMatricula;
    private javax.swing.JLabel lblNom;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField tfBusqueda;
    // End of variables declaration//GEN-END:variables
}