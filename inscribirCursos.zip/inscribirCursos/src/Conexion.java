import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.*; 

public class Conexion {
    private static Connection con=null;
    private static String driver="org.postgresql.Driver";
    private static String pwd="1234567890";
    private static String usuario="lupita";
    private static String url="jdbc:postgresql://localhost/cursos";
    //String url="jdbc:postgresql://localhost:5432/cursos";
    public static Connection getConnection(){
        try {  
            if(con==null){
                Runtime.getRuntime().addShutdownHook(new MiShDown());
                Class.forName(driver);
                con=DriverManager.getConnection(url,usuario,pwd);
                JOptionPane.showMessageDialog(null, "Conexion exitosa");
            }
        } catch (ClassNotFoundException | SQLException ex) {  
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Error al conectar "+ex);
        }
        return con;
    }
    
    static class MiShDown extends Thread{
        public void run(){
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
    }      
}
}